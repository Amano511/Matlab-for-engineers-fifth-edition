function output = C_to_F(x)
output = 9/5*x + 32;