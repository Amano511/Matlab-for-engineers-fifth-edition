function output = C_to_R(x)
F = 9/5*x + 32;
R = F+459.67;
output = R;