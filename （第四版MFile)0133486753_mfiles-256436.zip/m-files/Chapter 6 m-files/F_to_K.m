function output = F_to_K(x)
R = x + 459.67;
K = R*5/9;
output = K;